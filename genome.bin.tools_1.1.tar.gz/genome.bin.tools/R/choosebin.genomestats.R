choosebin.genomestats <-
function(x,taxon="Class",num.points=6,draw.polygon=TRUE,save=FALSE,file="interactive_bin.list") {
## Wrapper for picking out bin on plot interactively and immediately reporting the statistics on scaffolds contained in the bin
    thebin <- pick.bin.points(num.points=num.points,draw.polygon=draw.polygon)
    require(sp)
    inpolygon <- point.in.polygon(x$scaff$Ref_GC,x$scaff$Avg_fold,thebin$x,thebin$y)
    x.subset <- x$scaff[which(inpolygon==1),]
    x.shortlist <- as.character(x.subset$ID)
    theresult <- genomestatsbin(shortlist=x.shortlist,x=x,taxon=taxon,points=thebin,save=save,file=file)
    return(theresult)
}
