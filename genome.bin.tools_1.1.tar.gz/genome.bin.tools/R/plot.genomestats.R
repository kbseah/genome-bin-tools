plot.genomestats <-
function(x, cutoff=0, taxon="Class", assembly="",       # Basic inputs
                             marker=TRUE, ssu=FALSE, trna=FALSE, consensus=TRUE,legend=FALSE, textlabel=FALSE,  # Switches for various plot features
                             col="grey", log="y", main="default", xlab="GC",ylab="Coverage", ...) {
    if (cutoff > 0) {
        x$scaff <- subset(x$scaff,Length >= cutoff)
    }
    if (main=="default") {
        main=paste("Coverage vs. GC plot for metagenome ",as.character(assembly))
    }
    plot(x$scaff$Ref_GC,x$scaff$Avg_fold,pch=20,cex=sqrt(x$scaff$Length)/100, col=col, log=log, xlab=xlab, ylab=ylab, main=main, ...)
    if (marker && !is.na(x$mark)) {   # Add markers to plot if marker flag is TRUE and x$mark has been specified
        mark.stats <- generate.plot.colors(x$scaff, x$mark, taxon, consensus)
        points(mark.stats$Ref_GC,mark.stats$Avg_fold,pch=20,cex=sqrt(mark.stats$Length)/100,col=as.character(mark.stats$colors)) # Add points for scaffolds with marker genes, colored by their taxon
        if (legend) {       # If requested to add a legend to plot
            colorframe <- generate.legend.colors(x$scaff, x$mark, taxon, consensus)
            new.colorframe <- subset(colorframe,colors!="grey50")
            newrow <- c("singletons","grey50")
            new.colorframe <- rbind (new.colorframe,newrow)
            legend ("topright",legend=new.colorframe$taxon,cex=0.6,fill=as.character(new.colorframe$colors))
        }
    }
    if (ssu && !is.na(x$ssu)) {
        ssu.stats <- merge.scaff.marker(x$scaff, x$ssu, taxon, consensus=FALSE)
        points(ssu.stats$Ref_GC, ssu.stats$Avg_fold, pch=10, cex=2, col="black")
        if(textlabel==TRUE) {
            text(ssu.stats$Ref_GC,ssu.stats$Avg_fold,as.character(ssu.stats$taxon),pos=3,offset=0.2,font=2)
        }
    }
    if (trna && !is.na(x$trna)) {
        trna.stats <- merge(x$scaff,x$trna,by.x="ID",by.y="scaffold")
        points(trna.stats$Ref_GC,trna.stats$Avg_fold,pch=4,cex=1,col="black")
    }
}
