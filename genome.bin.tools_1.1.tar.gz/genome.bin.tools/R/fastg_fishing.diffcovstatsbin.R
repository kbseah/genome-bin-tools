fastg_fishing.diffcovstatsbin <-
function(x,bin,fastg.file,taxon="Class",save=FALSE,file="fished_bin.list") {
# Given a diffcovstats object x and a diffcovstatsbin object bin and a Fastg file,
#  return a new diffcovstatsbin object comprising scaffolds with connectivity to the original bin
    command <- "perl"
    script.path <- "/home/kbseah/tools/my_scripts/genome-bin-tools/fastg_parser.pl"                             # Change this to the path to your copy of fastg_parser.pl
    command.params <- paste(script.path,"-i",fastg.file,"-o /tmp/tmp.fishing_output -b - -r")                   # By default throws away fastg_parser.pl output to /tmp/
    fished.contigs.list <- system2(command,command.params,input=as.character(bin$diffcov$ID),stderr=NULL,stdout=TRUE)
    newbin <- diffcovstatsbin(fished.contigs.list,x,taxon=taxon,save=save,file=file)
    return(newbin)
}
