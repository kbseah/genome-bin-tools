diffcovstats.default <-
function (covstats1,covstats2,marker.list=NA,ssu.list=NA,trna.list=NA) {            # Import files and combine them into an object of class "diffcovstats"
    scaff1 <- read.table(file=as.character(covstats1),sep="\t",header=T)
    scaff2 <- read.table(file=as.character(covstats2),sep="\t",header=T)
    cov1 <- data.frame(ID=scaff1$ID,Avg_fold_1=scaff1$Avg_fold,Ref_GC=scaff1$Ref_GC,Length=scaff1$Length)    # Reformat and merge the coverage information from tables
    cov2 <- data.frame(ID=scaff2$ID,Avg_fold_2=scaff2$Avg_fold)
    diffcov <- merge(cov1,cov2,by="ID")
    if ( !is.na(marker.list) ) {                                                                   # If input marker file is not specified, make the field NA
        mark <- read.table(file=as.character(marker.list),sep="\t",header=T)
        Num_markers <- dim(mark)[1]
    } else {
        mark <- NA
        Num_markers <- NA
    }
    if ( !is.na(ssu.list) ) {
        ssu <- read.table(file=as.character(ssu.list),sep="\t",header=T)
        Num_SSU <- dim(ssu)[1]
    } else {
        ssu <- NA
        Num_SSU <- NA
    }
    if ( !is.na(trna.list) ) {
        trna <- read.table(file=as.character(trna.list),sep="\t",skip=3,header=F)
        names(trna) <- c("scaffold","tRNA_no","tRNA_begin","tRNA_end","tRNA_type","Anticodon","Intron_begin","Intron_end","Cove_score")
        Num_tRNAs <- dim(trna)[1]
    } else {
        trna <- NA
        Num_tRNAs <- NA
    }
    meancov1 <- sum(diffcov$Avg_fold_1*diffcov$Length)/sum(diffcov$Length)
    meancov2 <- sum(diffcov$Avg_fold_2*diffcov$Length)/sum(diffcov$Length)
    summarystats <- data.frame(Total_length=sum(diffcov$Length),Num_scaffolds=length(diffcov$ID),Mean_coverage_1=meancov1,Mean_coverage_2=meancov2,Num_markers,Num_SSU,Num_tRNAs)
    theresult <- list(diffcov=diffcov,mark=mark,ssu=ssu,trna=trna,summary=summarystats)
    theresult$call <- match.call()
    class(theresult) <- "diffcovstats"
    theresult
}
