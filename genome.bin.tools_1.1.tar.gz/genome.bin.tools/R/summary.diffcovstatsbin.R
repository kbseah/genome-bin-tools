summary.diffcovstatsbin <-
function(x) { # Identical to print method
    cat("Object of class diffcovstatsbin\n")
    cat ("\nSummary:\n")
    print(x$summary)
}
