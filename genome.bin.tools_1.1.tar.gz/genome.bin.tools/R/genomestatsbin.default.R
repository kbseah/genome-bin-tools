genomestatsbin.default <-
function(shortlist,x,taxon,points=NA,save=FALSE,file="interactive_bin.list") {
## Get bin from genomestats object and a shortlist of scaffolds which should be in the bin
    scaff.subset <- subset(x$scaff,ID %in% shortlist)
    bin.nummarkers <- NA    # Initialize value of bin.nummarkers for summary, in case the marker.list is not supplied
    bin.uniqmarkers <- NA
    bin.numtRNAs <- NA      # Likewise for number of tRNAs
    bin.uniqtRNAs <- NA
    bin.numSSUs <- NA
    bin.singlemarkers <- NA
    marker.tab <- NA
    marker.stats.subset <- NA
    tRNAs.tab <- NA
    trna.stats.subset <- NA
    if (!is.na(x$mark)) {
        marker.stats.subset <- subset(x$mark,scaffold %in% shortlist)
        bin.nummarkers <- dim(marker.stats.subset)[1]                                                                       # Total number of markers in the bin
        marker.tab <- table(marker.stats.subset$gene)                                                                       # Table of counts of each marker that is present (zeroes not shown)
        bin.uniqmarkers <- length(which(marker.tab > 0))                                                                    # Count total number of unique markers
        bin.singlemarkers <- length(which(marker.tab == 1))                                                                 # Count total number of single-copy markers
    }
    if (!is.na(x$ssu)) {
        ssu.stats.subset <- subset(x$ssu,scaffold %in% shortlist)
        bin.numSSUs <- dim(ssu.stats.subset)[1]     # Count total number of SSUs in the bin
    }
    if (!is.na(x$trna)) {
        trna.stats.subset <- subset(x$trna,scaffold %in% shortlist)
        bin.numtRNAs <- dim(trna.stats.subset)[1]
        tRNAs.tab <- table(trna.stats.subset$tRNA_type)
        bin.uniqtRNAs <- length(which(tRNAs.tab > 0))                                                                       # Count total number of unique tRNAs
    }
    bin.length <- sum(scaff.subset$Length)                                                                     # Total length of all scaffolds in the bin
    bin.numscaffolds <- dim(scaff.subset)[1]                                                                   # Total number of scaffolds in the bin
    bin.summary <- data.frame(Total_length=bin.length,Num_scaffolds=bin.numscaffolds,Num_markers=bin.nummarkers,Num_unique_markers=bin.uniqmarkers,Num_singlecopy_markers=bin.singlemarkers,
                              Num_SSUs=bin.numSSUs,Num_tRNAs=bin.numtRNAs,Num_tRNAs_types=bin.uniqtRNAs)
    if (save) {                                                                                                         # Option to export list of scaffolds contained in this bin, e.g. for reassembly
        write(as.vector(scaff.subset$ID),file=file)
    }
    result <- list(summary=bin.summary,marker.table=marker.tab,tRNA.table=tRNAs.tab,scaff=scaff.subset,mark=marker.stats.subset,
                   ssu=ssu.stats.subset,trna=trna.stats.subset,points=points)
    class(result) <- "genomestatsbin"
    return(result)
}
