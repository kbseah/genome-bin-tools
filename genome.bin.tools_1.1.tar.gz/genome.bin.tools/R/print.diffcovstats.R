print.diffcovstats <-
function(x) {
    cat("Object of class diffcovstats\n\n")
    cat("Call:\n")
    print(x$call)
    cat ("\nSummary:\n")
    print(x$summary)
}
