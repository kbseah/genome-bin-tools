merge.scaff.marker <-
function(scaffold.stats,marker.list,taxon,consensus=TRUE) {
## Merge table of scaffold statistics (output from pileup.sh in BBMap package) and table of marker statistics parsed by parse_phylotype_result.pl
## This function needed by other functions in this file
    marker.list[,"taxon"] <- marker.list[,which(names(marker.list)==taxon)]
    marker.stats <- merge(scaffold.stats,marker.list,by.x="ID",by.y="scaffold")
    if (consensus) {    # For scaffolds with multiple marker genes, take majority consensus of marker taxon assignment
        require(plyr)
        #scaffs.with.multi <- as.vector(names(table(marker.stats$ID)[which(table(marker.stats$ID)>1)]))
        #consensus.list <- ddply(marker.list, .(scaffold), function(x) levels(x$taxon)[which.max(tabulate(x$taxon))])
        consensus.list <- ddply(marker.list, .(scaffold), summarize, taxon=levels(taxon)[which.max(tabulate(taxon))])
        marker.stats <- merge(scaffold.stats,consensus.list,by.x="ID",by.y="scaffold")
    }
    return(marker.stats)
}
