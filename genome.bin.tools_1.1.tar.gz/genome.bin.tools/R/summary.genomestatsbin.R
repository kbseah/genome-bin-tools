summary.genomestatsbin <-
function(x) { # Identical to print method
    cat("Object of class genomestatsbin\n")
    cat ("\nSummary:\n")
    print(x$summary)
}
