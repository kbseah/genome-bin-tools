diffcovstats <-
function (covstats1,covstats2,marker.list,ssu.list,trna.list) UseMethod ("diffcovstats")
