summary.diffcovstats <-
function(x) {        # Identical to "print" behavior
    cat("Object of class diffcovstats\n\n")
    cat("Call:\n")
    print(x$call)
    cat ("\nSummary:\n")
    print(x$summary)
}
