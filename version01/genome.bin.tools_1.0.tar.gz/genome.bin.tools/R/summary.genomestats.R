summary.genomestats <-
function(x) {        # Identical to "print" behavior
    cat("Object of class genomestats\n\n")
    cat("Call:\n")
    print(x$call)
    cat ("\nSummary:\n")
    print(x$summary)
}
