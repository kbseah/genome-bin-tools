choosebin.diffcovstats <-
function(x,taxon="Class",num.points=6,draw.polygon=TRUE,save=FALSE,file="interactive_bin.list") {
## Wrapper for picking out bin on plot interactively and immediately reporting the statistics on scaffolds contained in the bin
    thebin <- pick.bin.points(num.points=num.points,draw.polygon=draw.polygon)
    require(sp)
    inpolygon <- point.in.polygon(x$diffcov$Avg_fold_1,x$diffcov$Avg_fold_2,thebin$x,thebin$y)
    x.subset <- x$diffcov[which(inpolygon==1),]
    x.shortlist <- as.character(x.subset$ID)
    theresult <- diffcovstatsbin(shortlist=x.shortlist,x=x,taxon=taxon,points=thebin,save=save,file=file)
    return(theresult)
}
