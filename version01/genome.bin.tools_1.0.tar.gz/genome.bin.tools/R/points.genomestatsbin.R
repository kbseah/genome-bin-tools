points.genomestatsbin <-
function(x,col="black", ...) {     # points method is customized for overlay onto genomestats plot
    points(x$scaff$Ref_GC,x$scaff$Avg_fold,pch=20,cex=sqrt(as.numeric(x$scaff$Length))/100,col=col, ...)
}
