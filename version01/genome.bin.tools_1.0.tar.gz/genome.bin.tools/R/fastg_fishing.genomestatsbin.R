fastg_fishing.genomestatsbin <-
function(x,bin,fastg.file,taxon="Class",save=FALSE,file="fished_bin.list") {
# Given a genomestats object x and a genomestatsbin object bin and a Fastg file,
#  return a new genomestatsbin object comprising scaffolds with connectivity to the original bin
    command <- "perl"
    script.path <- "/home/kbseah/tools/my_scripts/genome-bin-tools/fastg_parser.pl"                             # Change this to the path to your copy of fastg_parser.pl
    command.params <- paste(script.path,"-i",fastg.file,"-o /tmp/tmp.fishing_output -b - -r")                   # By default throws away fastg_parser.pl output to /tmp/
    fished.contigs.list <- system2(command,command.params,input=as.character(bin$scaff$ID),stderr=NULL,stdout=TRUE)
    newbin <- genomestatsbin(fished.contigs.list,x,taxon=taxon,save=save,file=file)
    return(newbin)
}
