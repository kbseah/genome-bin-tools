genomestats <-
function (covstats,marker.list,ssu.list,trna.list) UseMethod ("genomestats")
