#' Generic operation for merging and subsetting two gbtbin objects
#' 
#' @param x1 Object of class gbtbin
#' @param x2 Object of class gbtbin
#' @param shortlist Vector of contig IDs to make new bin
#' @return Object of class gbtbin
#' @keywords internal

setOperation <- function(x1, x2, shortlist) UseMethod("setOperation")
setOperation.gbtbin <- function(x1,x2,shortlist) {
## Generic operation for merging and subsetting two gbtbin objects
    scaff.add <- unique (rbind(x1$scaff,x2$scaff))
    if (shortlist[1] == "all") {
        shortlist <- as.character(scaff.add$ID)
    }
    scaff.add <- subset (scaff.add, ID %in% shortlist)
    covs.add <- unique (rbind(x1$covs,x2$covs))
    covs.add <- subset(covs.add, ID %in% shortlist)
    markTab.add <- NA
    ssuTab.add <- NA
    trnaTab.add <- NA
    # Summary stats
    bin.nummarkers <- NA    # Initialize value of bin.nummarkers for summary, in case the marker.list is not supplied
    bin.uniqmarkers <- NA
    bin.numtRNAs <- NA      # Likewise for number of tRNAs
    bin.uniqtRNAs <- NA
    bin.numSSUs <- NA
    bin.singlemarkers <- NA
    marker.tab <- NA
    tRNAs.tab <- NA
    ##
    if (!is.na(x1$markTab) || !is.na(x2$markTab)) {
        markTab.add <- unique (rbind(x1$markTab,x2$markTab))
        bin.nummarkers <- dim(markTab.add)[1]  # Total number of markers in the bin
        marker.tab <- table(markTab.add$gene)  # Table of counts of each marker that is present (zeroes not shown)
        bin.uniqmarkers <- length(which(marker.tab > 0))  # Count total number of unique markers
        bin.singlemarkers <- length(which(marker.tab == 1))
    }
    if (!is.na(x1$ssuTab) || !is.na(x2$ssuTab)) {
        ssuTab.add <- unique (rbind(x1$ssuTab,x2$ssuTab))
        bin.numSSUs <- dim(ssuTab.add)[1]
    }
    if (!is.na(x1$trnaTab) || !is.na(x2$trnaTab)) {
        trnaTab.add <- unique (rbind(x1$trnaTab,x2$trnaTab))
        bin.numtRNAs <- dim(trnaTab.add)[1]
        tRNAs.tab <- table(trnaTab.add$tRNA_type)
        bin.uniqtRNAs <- length(which(tRNAs.tab > 0))
    }
    bin.length <- sum(scaff.add$Length)
    bin.numscaffolds <- dim(scaff.add)[1]
    bin.summary <- data.frame(Total_length=bin.length,Num_scaffolds=bin.numscaffolds,
                              Num_markers=bin.nummarkers,Num_unique_markers=bin.uniqmarkers,Num_singlecopy_markers=bin.singlemarkers,
                              Num_SSUs=bin.numSSUs,Num_tRNAs=bin.numtRNAs,Num_tRNAs_types=bin.uniqtRNAs)
    result <- list (scaff=scaff.add,covs=covs.add,markTab=markTab.add,ssuTab=ssuTab.add,trnaTab=trnaTab.add,
                    summary=bin.summary,marker.table=marker.tab,tRNA.table=tRNAs.tab,points=NA,slice=NA)
    class(result) <- "gbtbin"
    return(result)
}
