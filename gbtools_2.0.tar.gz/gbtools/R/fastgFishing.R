#' Perform connectivity fishing with Fastg file
#'
#' Find contigs connected to existing gbtbin object, using connectivity from
#' an external Fastg file
#'
#' @param x Object of class gbt, from which the bin object was defined
#' @param bin Object of class gbtbin, defined from the gbt object x
#' @param fastg.file Path to Fastg file for the metagenome assembly of x
#' @return Object of class gbtbin
#' @export

fastgFishing <- function(x, bin, fastg.file, ... ) UseMethod ("fastgFishing")  # Defines generic for fastgFishing function
