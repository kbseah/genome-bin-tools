#' Print summary of gbt objectbin
#'
#' @param x Object of class gbtbin
#' @return data.frame summarizing contents of x
#' @seealso \code{\link{gbtbin}}, \code{\link{summary.gbtbin}}
#' @export
print.gbtbin <- function(x) {
    cat("Object of class gbtbin\n")
    cat ("\nSummary:\n")
    print(x$summary)
}