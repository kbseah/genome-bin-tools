#' Create new gbt object
#'
#' Creates new gbt object from coverage data, taxonomic markers, and other
#' data
#'
#' See documentation online https://github.com/kbseah/genome-bin-tools for
#' fuller instructions on generating the input files required.
#'
#' @param covstats File(s) with coverage statistics of a metagenomic assembly;
#'                  output of pileup.sh in BBTools package (required). More
#'                  than one file can be specified with c().
#' @param mark Table of scaffolds with marker genes and taxonomic information
#'              for each marker. E.g. AMPHORA2 or Phyla-AMPHORA marker sets
#'              and output parsed by parse_phylotype_result.pl. (optional)
#' @param ssu Table of scaffolds with SSU rRNA genes, and taxonomic info
#'             for each SSU. E.g. use get_ssu_for_genome_bin_tools.pl.
#'             (optional)
#' @param tnra Table of tRNA genes found in assembly. Can use the output from
#'              tRNAscan-SE directly. (optional)
#'
#' @return Object of class gbt
#'
#' @seealso \code{\link{gbtbin}}, \code{link{choosebin}}
#'
#' @export
gbt.default <- function (covstats, mark=NA, ssu=NA, trna=NA) {
## Create new gbt objects
    if ( class(covstats)!="character" || length(covstats)==0 ) {  # Check that covstats argument is character class
        cat ("covstats argument must be a list of file names!\n")
    }
    else {
        # Check how many covstats files have been supplied
        if (length(covstats)==1) {
            scaff <- read.table(file=as.character(covstats),sep="\t",header=T)
            covs <- data.frame(ID=scaff$ID,scaff$Avg_fold)
        }
        else {
            scaff <- read.table(file=as.character(covstats[1]),sep="\t",header=T)  # Contains all other data associated per contig
            covs <- data.frame(ID=scaff$ID,scaff$Avg_fold)  # Contains scaffold ID and coverage data
            for (i in 2:length(covstats)) {  # Read the other covstats files
                scafftemp <- read.table(file=as.character(covstats[i]),sep="\t",header=T)
                covs <- merge(covs,data.frame(ID=scafftemp$ID,scafftemp$Avg_fold),by="ID")
            }
        }
        if ( !is.na(mark) ) {  # Read marker table
            markTab <- read.table(file=as.character(mark),sep="\t",header=T)
            numMarks <- dim(markTab)[1]
        } else {
            markTab <- NA
            numMarks <- NA
        }
        if ( !is.na(ssu) ) {  # Read SSU marker table
            ssuTab <- read.table(file=as.character(ssu),sep="\t",header=T)
            numSsu <- dim(ssuTab)[1]
        } else {
            ssuTab <- NA
            numSsu <- NA
        }
        if ( !is.na(trna) ) {  # Read tRNA marker table
            trnaTab <- read.table(file=as.character(trna),sep="\t",skip=3,header=F)
            names(trnaTab) <- c("scaffold","tRNA_no","tRNA_begin","tRNA_end","tRNA_type","Anticodon","Intron_begin","Intron_end","Cove_score")
            numTrna <- dim(trnaTab)[1]
        } else {
            trnaTab <- NA
            numTrna <- NA
        }
        summarystats <- data.frame(Total_length=sum(scaff$Length),Num_scaffolds=length(scaff$ID),Num_markers=numMarks,Num_SSU=numSsu,Num_tRNAs=numTrna)
        result <- list(scaff=scaff,covs=covs,markTab=markTab,ssuTab=ssuTab,trnaTab=trnaTab,summary=summarystats)
        result$call <- match.call()
        class(result) <- "gbt"
        result
    }    
}
