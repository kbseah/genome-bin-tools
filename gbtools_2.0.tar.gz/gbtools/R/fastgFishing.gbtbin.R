#' Perform connectivity fishing with Fastg file
#'
#' Find contigs connected to existing gbtbin object, using connectivity from
#' an external Fastg file
#'
#' @param x Object of class gbt, from which the bin object was defined
#' @param bin Object of class gbtbin, defined from the gbt object x
#' @param fastg.file Path to Fastg file for the metagenome assembly of x
#' @return Object of class gbtbin
#' @export
fastgFishing.gbtbin <- function(x,bin,fastg.file,taxon="Class",save=FALSE,file="fished_bin.list") {
    command <- "perl"
## REPLACE THIS PATH WITH YOUR OWN PATH !! #########################################
    script.path <- "/home/kbseah/tools/my_scripts/genome-bin-tools/fastg_parser.pl" 
####################################################################################
    command.params <- paste(script.path,"-i",fastg.file,"-o /tmp/tmp.fishing_output -b - -r")                   # By default throws away fastg_parser.pl output to /tmp/
    fished.contigs.list <- system2(command,command.params,input=as.character(bin$scaff$ID),stderr=NULL,stdout=TRUE)
    newbin <- gbtbin(shortlist=fished.contigs.list,x=x,slice=NA,taxon=taxon,save=save,file=file)
    return(newbin)
}