#' Create gbtbin from gbt object
#'
#' Creates object of class gbtbin from existing gbt object, representing a
#' genome bin defined from a metagenome assembly.
#'
#' This function is called by \code{\link{choosebin}}, but can be called
#' directly by the user, given a shortlist of contigs in the bin.
#'
#' @param shortlist List of contigs in the new bin (required)
#' @param x Object of class gbt
#' @param slice Numeric vector describing which coverage values were used to
#'               draw the plot from which the bin was selected by choosebin.
#'               Use NA if not calling this function from choosebin.
#' @param taxon For internal use
#' @param points Numeric vector describing points used to select the bin from
#'                a plot by choosebin. Use NA if not calling this function
#'                from choosebin.
#' @param save Save list of contigs to external file? (logical, default FALSE)
#' @param file File name to save contigs, if save=TRUE.
#'
#' @return Object of class gbtbin
#' @seealso \code{\link{gbt}}, \code{\link{choosebin}}
#' @export
gbtbin.default <- function(shortlist,x,slice,taxon,points=NA,save=FALSE,file="interactive_bin.list") {
    scaff.subset <- subset(x$scaff, ID%in% shortlist)
    covs.subset <- subset(x$covs, ID%in%shortlist)
    markTab.subset <- NA
    ssuTab.subset <- NA
    trnaTab.subset <- NA
    # Summary statistics initialize
    bin.nummarkers <- NA
    bin.uniqmarkers <- NA
    bin.numtRNAs <- NA
    bin.uniqtRNAs <- NA
    bin.numSSUs <- NA
    bin.singlemarkers <- NA
    marker.tab <- NA
    tRNAs.tab <- NA
    ###
    if (!is.na (x$markTab)) {
        markTab.subset <- subset(x$markTab,scaffold%in% shortlist)
        bin.nummarkers <- dim(markTab.subset)[1]
        marker.tab <- table(markTab.subset$gene)
        bin.uniqmarkers <- length(which(marker.tab > 0))
        bin.singlemarkers <- length(which(marker.tab ==1))
    }
    if (!is.na (x$ssuTab)) {
        ssuTab.subset <- subset(x$ssuTab,scaffold%in%shortlist)
        bin.numSSUs <- dim(ssuTab.subset)[1]
    }
    if (!is.na (x$trnaTab)) {
        trnaTab.subset <- subset(x$trnaTab,scaffold%in% shortlist)
        bin.numtRNAs <- dim(trnaTab.subset)[1]
        tRNAs.tab <- table (trnaTab.subset$tRNA_type)
        bin.uniqtRNAs <- length(which(tRNAs.tab > 0))
    }
    bin.length <- sum(scaff.subset$Length)
    bin.numscaffolds <- dim(scaff.subset)[1]
    bin.summary <- data.frame(Total_length=bin.length,Num_scaffolds=bin.numscaffolds,Num_markers=bin.nummarkers,
                              Num_unique_markers=bin.uniqmarkers,Num_singlecopy_markers=bin.singlemarkers,
                              Num_SSUs=bin.numSSUs,Num_tRNAs=bin.numtRNAs,Num_tRNAs_types=bin.uniqtRNAs)
    if (save) {
        write(as.vector(scaff.subset$ID),file=file)
    }
    result <- list(scaff=scaff.subset, covs=covs.subset,
                   markTab=markTab.subset,ssuTab=ssuTab.subset,trnaTab=trnaTab.subset,
                   summary=bin.summary,marker.table=marker.tab,tRNA.table=tRNAs.tab,points=points,slice=slice)
    class(result) <- "gbtbin"
    return(result)
}