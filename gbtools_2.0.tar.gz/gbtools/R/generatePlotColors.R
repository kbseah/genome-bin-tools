#' Generates colors for marker gene phylotypes in plot
#'
#' @inheritParams generateLegendColors
#' @return data.frame with color assignments for each scaffold
#' @keywords internal
#'
generatePlotColors <- function(scaffold.stats, marker.list, taxon, consensus) {           # This took a very long time to get it right
    marker.stats <- mergeScaffMarker(scaffold.stats,marker.list,taxon, consensus)          # Some table merging to have points to plot for the markers
    marker.list[,"taxon"] <- marker.list[,which(names(marker.list)==taxon)]
    singleton.taxa <- names(table(marker.list$taxon)[which(table(marker.list$taxon)==1)])       # Count how many taxa are only supported by one marker gene
    top.taxon <- names(table(marker.list$taxon)[which.max(table(marker.list$taxon))])           # Which taxon has the most marker genes?
        # Use which.max() because it breaks ties. Otherwise all genomes with same number of marker genes will have same color!
        # Important: Identification of singleton taxa uses the original marker.list because after "consensus",
        #  each scaffold has only one taxon assignment and scaffolds with >1 marker will be undercounted
    ### For plot colors - identify singleton taxa and the taxon with the highest marker counts, and assign them special colors
    taxnames <- names(table(marker.stats$taxon))                                                    # Names of taxa
    taxcolors <- rep("",length(names(table(marker.stats$taxon))))                                   # Create vector to hold color names
    taxcolors[which(names(table(marker.stats$taxon)) %in% singleton.taxa)] <- "grey50"              # Which taxa are singletons? Give them the color "grey50"
    numsingletons <- length(taxcolors[which(names(table(marker.stats$taxon)) %in% singleton.taxa)]) # Count how many singleton taxa
    taxcolors[which(names(table(marker.stats$taxon))==top.taxon)] <- "red"                          # Which taxon has the most marker genes? Give it the color "red"
    numcolors <- length(table(marker.stats$taxon)) - 1 - numsingletons                              # How many other colors do we need, given that all singletons have same color?
    thecolors <- rainbow(numcolors,start=1/6,end=5/6)                                               # Generate needed colors, from yellow to magenta, giving red a wide berth
    taxcolors[which(!(names(table(marker.stats$taxon)) %in% singleton.taxa)  & names(table(marker.stats$taxon))!=top.taxon)] <- thecolors
    colorframe <- data.frame(taxon=taxnames,colors=taxcolors)                                       # Data frame containing which colors correspond to which taxa
    marker.stats <- merge(marker.stats,colorframe,by="taxon")                                       # Merge this by taxon into the marker.stats table for plotting (this works even when consensus option is called)
    return(marker.stats)
}