#' Take union of two gbtbin objects
#'
#' Take union of two gbtbin objects. Equivalent to the R union function
#'
#' Self explanatory...
#' 
#' @param x1 Object of class gbtbin
#' @param x2 Object of class gbtbin
#'
#' @return Object of class gbtbin
#'
#' @seealso \code{\link{lej}}
#' @export
add.gbtbin <- function(x1,x2) {
    result <- setOperation(x1=x1,x2=x2,shortlist="all")
    return(result)
}