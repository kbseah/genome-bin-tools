#' Subset a gbt or gbtbin object by marker gene taxonomy
#'
#' @param param Taxonomic level to make subset (default "Class")
#' @param value Value of the taxon to make subset (default
#'               "Gammaproteobacteria")
#' @inheritParams winnow
#' @return Object of class gbtbin
#' @seealso \code{\link{winnow}}, \code{\link{gbt}}
#' @export
#'
winnowMark <- function(x,param,value,save,file) UseMethod("winnowMark")
winnowMark.gbt <- function(x,param="Class",value="Gammaproteobacteria",save=FALSE,file="bin_scaffolds.list") {
    scafflist <- as.character(x$markTab$scaffold[which(x$markTab[,which(names(x$markTab)==param)]==value)])
    bin <- gbtbin (shortlist=scafflist, x=x, points=NA, slice=NA, save=save,file=file)
    return(bin)
}
winnowMark.gbtbin <- winnowMark.gbt