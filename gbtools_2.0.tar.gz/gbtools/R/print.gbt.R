#' Print summary of gbt object
#'
#' @param x Object of class gbt
#' @return data.frame summarizing contents of x
#' @seealso \code{\link{gbt}}, \code{\link{summary.gbt}}
#' @export
print.gbt <- function(x) {
    cat("Object of class gbt\n\n")
    cat("Call:\t")
    print(x$call)
    cat("\nSummary:\n")
    print(x$summary)
}
