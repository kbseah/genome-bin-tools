#' Add points to plot of gbt or gbtbin object
#'
#' Add points to GC-coverage or differential coverage plots from a gbt object
#'
#' See \code{\link{plot.gbt}} for more details on gbt plots.
#'
#' @inheritParams plot.gbt
#' @param slice
#'
#' @seealso \code{\link{plot.gbt}}, \code{\link{plot.gbtbin}}
#' @export
#'
points.gbtbin <- function(x,col="black", slice="default", cutoff=0, pch=20, ...) {
    if (slice == "default") {  # Defaults to the same slice used to choose the bin
        slice <- x$slice
    }
    if (is.na(slice) || !is.numeric(slice) || length(slice) > 2) { # Catch invalid slice values
        cat ("Please specify valid value for slice option for this bin\n")
    } else if (is.numeric(slice) && length(slice)==1) {
        X <- merge(data.frame(ID=x$scaff$ID,Ref_GC=x$scaff$Ref_GC,Length=x$scaff$Length),
                   data.frame(ID=x$covs$ID,Avg_fold=x$covs[slice[1]+1]),
                   by="ID")
        names(X) <- c("ID","Ref_GC","Length","Avg_fold")
        if (cutoff > 0) {
            X <- subset(X, Length >= cutoff)
        }
        points(X$Ref_GC,X$Avg_fold,pch=pch,cex=sqrt(as.numeric(X$Length))/100,col=col, ...)
    } else if (is.numeric(slice) && length(slice)==2) {
        X <- merge(data.frame(ID=x$scaff$ID,Ref_GC=x$scaff$Ref_GC,Length=x$scaff$Length),
                   data.frame(ID=x$covs$ID,Avg_fold_1=x$covs[slice[1]+1],Avg_fold_2=x$covs[slice[2]+1]),
                   by="ID")
        names(X) <- c("ID","Ref_GC","Length","Avg_fold_1","Avg_fold_2")
        if (cutoff > 0 ) {
            X <- subset(X,Length >= cutoff)
        }
        points(X$Avg_fold_1,X$Avg_fold_2,pch=pch,cex=sqrt(as.numeric(X$Length))/100,col=col, ...)
    } else { cat ("Please specify valid value for slice option for this bin\n")}
}