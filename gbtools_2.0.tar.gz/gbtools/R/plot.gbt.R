#' Plot object of class gbt
#'
#' Plot GC-coverage or differential coverage plots from a gbt object
#'
#' The plot method for gbt objects can produce both GC-coverage and
#' differential coverage plots. A gbt object contains scaffold data and
#' annotations for a given metagenome, along with the coverage of each
#' scaffold for one or more samples. To plot GC-coverage plots, the sample
#' to use for the coverage data is specified by giving the number of the
#' sample to the slice parameter. To plot differential-coverage plots, the
#' numbers of the two samples for comparison are given to slice as a vector
#' e.g. c(1,2). The first sample is plotted as the x-axis and the second as
#' the y-axis. Supplying a vector with more than 2 elements, or a non-
#' numeric value will return an error.
#' Genome bins can be interactively chosen from a gbt plot with the
#' \code{\link{choosebin}} function; the same slice argument must be passed
#' to the choosebin function as the plot function, otherwise the results will
#' be meaningless!
#' 
#' @param x Object of class gbt
#' @param slice For plotting coverage data, which sample to use? (see
#'               Details section below)
#' @param cutoff Minimum length to plot contigs (numeric, default 1000)
#' @param taxon Taxonomic level for coloring the taxonomic markers, e.g.
#'               "Class" or "Phylum". (default "Class")
#' @param assemblyName Name of the metagenome, for plot title
#' @param marker Color plot by taxon markers? (logical, default TRUE)
#' @param gc Color plot by GC% instead of taxon markers? Only used for
#'            differential coverage plots, i.e. when two values are supplied
#'            to the slice parameter. (logical, default FALSE)
#' @param ssu Draw markers for SSU genes? (logical, default FALSE)
#' @param trna Draw markers for tRNA genes? (logical, default FALSE)
#' @param consensus For contigs with more than one marker gene with conflict
#'                   in taxonomy, take majority rule consensus? (logical,
#'                   default TRUE)
#' @param legend Draw legend? (logical, default FALSE)
#' @param textlabel Label SSU markers with taxon? (logical, default FALSE)
#' @param col Color for points (default "grey")
#' @param log Which axes should be logarithmic scale
#' @param main Custom label for plot title
#' @param xlab Custom label for x-axis label
#' @param ylab Custom label for y-axis label
#' @param ... See par for more plot options
#'
#' @return New graphics object and plot, or error message
#' @export
#' @seealso \code{\link{gbt}}
#'
plot.gbt <- function(x, slice=1, cutoff=1000, taxon="Class", assemblyName="",  # Basic inputs
                     marker=TRUE, gc=FALSE, ssu=FALSE, trna=FALSE, consensus=TRUE, legend=FALSE, textlabel=FALSE,  # Switches for plot features
                     col="grey", log="default", main="default", xlab="default", ylab="default", ...) {
## Plot method for gbt objects
    if (is.na(slice[1]) || !is.numeric(slice)) {
        cat("Please supply valid value for slice option\n")
    } else if (!is.na(slice[1]) && length(slice)==1) {
    ## GC-Coverage plot
        # Make a new data.frame for plotting
        X <- merge( data.frame(ID=x$scaff$ID,Ref_GC=x$scaff$Ref_GC,Length=x$scaff$Length),
                   data.frame(ID=x$covs$ID,Avg_fold=x$covs[slice[1]+1]),
                   by="ID")
        names(X) <- c("ID","Ref_GC","Length","Avg_fold")
        
        if (cutoff > 0) {  # Minimum length cutoff for contigs to be plotted
            X <- subset(X,Length >= cutoff)
        }
        if (main=="default") {  # Plot title
            main <- paste("Coverage-GC plot for metagenome ",as.character(assemblyName))
        }
        if (xlab=="default") {  # X-axis label default
            xlab <- "GC"
        }
        if (ylab=="default") {  # Y-axis label default
            ylab <- paste("Coverage ",as.character(slice[1]))
        }
        if (log=="default") {  # Default y-axis on logarithmic scale
            log <- "y"
        }
        plot(X$Ref_GC,X$Avg_fold,pch=20,cex=sqrt(X$Length)/100,
             col=col,log=log,main=main, xlab=xlab,ylab=ylab, ...)
        if (marker && !is.na(x$markTab)) {
            mark.stats <- generatePlotColors(X,x$markTab,taxon,consensus)
            points(mark.stats$Ref_GC,mark.stats$Avg_fold,pch=20,cex=sqrt(mark.stats$Length)/100,col=as.character(mark.stats$colors))
            if (legend) {
                colorframe <- generateLegendColors(X,x$markTab,taxon,consensus)
                new.colorframe <- subset(colorframe,colors!="grey50")
                newrow <- c("singletons","grey50")
                new.colorframe <-rbind (new.colorframe,newrow)
                legend("topright",legend=new.colorframe$taxon,cex=0.6,fill=as.character(new.colorframe$colors))
            }
        }
        if (ssu && !is.na(x$ssuTab)) {
            ssu.stats <- mergeScaffMarker(X,x$ssuTab, taxon, consensus=FALSE)
            points(ssu.stats$Ref_GC, ssu.stats$Avg_fold,pch=10,cex=2,col="black")
            if (textlabel==TRUE) {
                text(ssu.stats$Ref_GC,ssu.stats$Avg_fold,as.character(ssu.stats$taxon),pos=3,offset=0.2,font=2)
            }
        }
        if (trna && !is.na(x$trnaTab)) {
            trna.stats <- merge(X, x$trnaTab, by.x="ID",by.y="scaffold")
            points(trna.stats$Ref_GC,trna.stats$Avg_fold,pch=4,cex=1,col="black")
        }
    } else if (!is.na(slice[1]) && length(slice)==2) {
    ## Differential coverage plot
        # Make a new data.frame for plotting
        X <- merge (data.frame (ID=x$scaff$ID,Ref_GC=x$scaff$Ref_GC,Length=x$scaff$Length),
                    data.frame (ID=x$covs$ID,Avg_fold_1=x$covs[slice[1]+1],Avg_fold_2=x$covs[slice[2]+1]),
                    by="ID")
        names(X) <- c("ID","Ref_GC","Length","Avg_fold_1","Avg_fold_2")
        # Length cutoff
        if (cutoff > 0 ) {
            X <- subset(X,Length>=cutoff)
        }
        if (main == "default") {  # Default plot title
            main <- paste("Differential coverage plot for metagenome ",as.character(assemblyName))
        }
        if (xlab=="default") {  # Default X-axis label
            xlab <- paste("Coverage ",slice[1])
        }
        if (ylab=="default") {  # Default Y axis label
            ylab <- paste("Coverage ",slice[2])
        }
        if (log=="default") {  # Default both x- and y-axis on logarithmic scale
            log <- "xy"
        }
        gbr <- colorRampPalette(c("green","blue","orange","red"))  # Define GC palette colors; from Albertsen script
        if (gc && marker & !is.na(x$markTab)) {  # Catch invalid option combination
            cat("plase choose to plot only with GC or marker coloring, but not both!\n")
        }
        else if (gc && !marker) {  # Color plot by GC% values
            palette (adjustcolor(gbr(70)))
            plot(X$Avg_fold_1,X$Avg_fold_2,pch=20,cex=sqrt(X$Length)/100,col=X$Ref_GC*100,
                 main=main,log=log,xlab=xlab,ylab=ylab,...)
            if (legend) {
                legendcolors <- c("20","30","40","50","60","70","80")
                legend ("topright",legend=as.character(legendcolors),fill=as.numeric(legendcolors))
            }
        }
        else if (!gc && !is.na(x$markTab) && marker) {  # Color plot by markers
            plot (X$Avg_fold_1,X$Avg_fold_2,pch=20,cex=sqrt(X$Length)/100,
                  main=main,col=col,log=log,ylab=ylab,xlab=xlab, ...)
            mark.stats <- generatePlotColors(X,x$markTab,taxon,consensus)
            points(mark.stats$Avg_fold_1,mark.stats$Avg_fold_2,pch=20,cex=sqrt(mark.stats$Length)/100,
                   col=as.character(mark.stats$colors))
            if (legend) {
                colorframe <- generateLegendColors(X,x$markTab,taxon,consensus)
                new.colorframe <- subset(colorframe,colors!="grey50")
                newrow <- c("singletons","grey50")
                new.colorframe <- rbind (new.colorframe,newrow)
                legend("topright",legend=new.colorframe$taxon,cex=0.6,fill=as.character(new.colorframe$colors))
            }
        }
        else if (!gc && !marker) {  # Do not color plot
            plot (X$Avg_fold_1,X$Avg_fold_2,pch=20,cex=sqrt(X$Length)/100,
                  main=main,col=col,log=log,xlab=xlab,ylab=ylab, ...)
        }
        if (!(gc&&marker)) {
            if (ssu && !is.na(x$ssuTab)) {  # Add SSU markers to plot
                ssu.stats <-mergeScaffMarker (X,x$ssuTab,taxon,consensus=FALSE)
                points(ssu.stats$Avg_fold_1,ssu.stats$Avg_fold_2,pch=10,cex=2,col="black")
                if (textlabel==TRUE) {
                    text(ssu.stats$Avg_fold_1,ssu.stats$Avg_fold_2,as.character(ssu.stats$taxon),pos=3,cffset=0.2,font=2)
                }
            }
            if (trna && !is.na(x$trnaTab)) {  # Add tRNA markers to plot
                trna.stats <- merge(X,x$trnaTab,by.x="ID",by.y="scaffold")
                points(trna.stats$Avg_fold_1,trna.stats$Avg_fold_2,pch=4,cex=1,col="black")
            }
        }
    }
}