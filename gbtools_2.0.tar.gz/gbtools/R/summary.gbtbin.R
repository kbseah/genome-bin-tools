#' Print summary of gbtbin object
#'
#' @param x Object of class gbtbin
#' @return data.frame summarizing contents of x
#' @seealso \code{\link{gbtbin}}, \code{\link{print.gbtbin}}
#' @export
summary.gbtbin <- print.gbtbin  # Identical to print method
