winnow.mark <- 
function(x,param="Class",value="Gammaproteobacteria",save=FALSE,file="bin_scaffolds.list") {
    # "Winnow a genomestats or diffcovstats by its marker table
    # Only return those scaffolds whose marker parameter "param" is of value "value" (e.g. only return all scaffolds with markers whose Class designation is Gammaproteobacteria)
    if (class(x) == "genomestatsbin" | class(x) == "genomestats") {
        scafflist <- as.character(x$mark$scaffold[which (x$mark[,which(names(x$mark)==param)] == value)])
        winnowedbin <- genomestatsbin (shortlist=scafflist, x=x, points=NA, save=save, file=file)
        return(winnowedbin)
    }
    if (class(x) == "diffcovstatsbin" | class(x) == "diffcovstats") {
        scafflist <- as.character(x$mark$scaffold[which (x$mark[,which(names(x$mark)==param)] == value)])
        winnowedbin <- diffcovstatsbin (shortlist=scafflist, x=x, points=NA, save=save, file=file)
        return(winnowedbin)
    }
    else {cat("Object must be of class genomestats, genomestatsbin, diffcovstats, or diffcovstatsbin!\n")}
}