print.genomestats <-
function(x) {
    cat("Object of class genomestats\n\n")
    cat("Call:\n")
    print(x$call)
    cat ("\nSummary:\n")
    print(x$summary)
}
