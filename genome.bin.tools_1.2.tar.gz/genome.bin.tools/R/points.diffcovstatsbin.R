points.diffcovstatsbin <-
function(x,col="black", ...) {     # points method is customized for overlay onto genomestats plot
    points(x$diffcov$Avg_fold_1,x$diffcov$Avg_fold_2,pch=20,cex=sqrt(as.numeric(x$diffcov$Length))/100,col=col, ...)
}
