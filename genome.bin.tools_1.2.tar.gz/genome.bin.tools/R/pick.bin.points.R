pick.bin.points <-
function(num.points=6,draw.polygon=TRUE) {
## Wrapper for locator() and polygon() to perform interactive binning on the current plot. Returns the polygon vertices which can be used in get.bin.stats()
    thepoints <- locator(num.points,pch=20,type="p")
    if (draw.polygon) { polygon(thepoints) }
    return(thepoints)
}
