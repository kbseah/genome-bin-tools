print.diffcovstatsbin <-
function(x) {
    cat("Object of class diffcovstatsbin\n")
    cat ("\nSummary:\n")
    print(x$summary)
}
