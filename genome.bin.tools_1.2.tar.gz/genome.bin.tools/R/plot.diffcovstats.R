plot.diffcovstats <-
function(x, cutoff=0, taxon="Class", assembly="",       # Basic inputs
                             gc=FALSE, marker=TRUE, ssu=FALSE, trna=FALSE, consensus=TRUE,legend=FALSE, textlabel=FALSE,  # Switches for various plot features
                             col="grey", log="xy", xlab="Coverage, sample 1", ylab="Coverage, sample 2", ...) {
    if (cutoff > 0) {
        x$diffcov <- subset(x$diffcov,Length >= cutoff)
    }
    gbr <- colorRampPalette(c("green","blue","orange","red"))   # Define colors for GC palette -- from Albertsen script
    if (gc && !is.na(x$mark) && marker) {       # Plot both with GC colors and Marker colors
        cat ("Please choose to plot only with GC or marker coloring, not both.\n")
    }
    else if (gc && !marker) {                   # Plot only with GC colors
        palette(adjustcolor(gbr(70)))           # Apply palette
        plot(x$diffcov$Avg_fold_1,x$diffcov$Avg_fold_2,pch=20,cex=sqrt(x$diffcov$Length)/100, col=x$diffcov$Ref_GC*100,
             main=paste("Differential coverage colored by GC, metagenome ", as.character(assembly)), log=log, xlab=xlab, ylab=ylab,  ...) # Base plot
        if (legend) {   # Add color scale for GC
            legendcolors <- c("20","30","40","50","60","70")    # Values to show in legend
            legend("topright",legend=as.character(legendcolors),fill=as.numeric(legendcolors))
        }
    }
    else if (!gc && !is.na(x$mark) && marker) { # Plot only with Marker colors
        plot(x$diffcov$Avg_fold_1,x$diffcov$Avg_fold_2,pch=20,cex=sqrt(x$diffcov$Length)/100,
             main=paste("Differential coverage colored by markers, metagenome ", as.character(assembly)), col=col, log=log, xlab=xlab, ylab=ylab,  ...) # Base plot
        mark.stats <- generate.plot.colors(x$diffcov, x$mark, taxon, consensus)
        points(mark.stats$Avg_fold_1,mark.stats$Avg_fold_2,pch=20,cex=sqrt(mark.stats$Length)/100,col=as.character(mark.stats$colors)) # Add points for scaffolds with marker genes, colored by their taxon
        if (legend) {       # If requested to add a legend to plot
            colorframe <- generate.legend.colors(x$diffcov, x$mark, taxon, consensus)
            new.colorframe <- subset(colorframe,colors!="grey50")
            newrow <- c("singletons","grey50")
            new.colorframe <- rbind (new.colorframe,newrow)
            legend ("topright",legend=new.colorframe$taxon,cex=0.6,fill=as.character(new.colorframe$colors))
        }
    }
    else if (!gc && !marker) {                  # Plot uncolored
        plot(x$diffcov$Avg_fold_1,x$diffcov$Avg_fold_2,pch=20,cex=sqrt(x$diffcov$Length)/100,
             main=paste("Differential coverage plot, metagenome ", as.character(assembly)), col=col, log=log, xlab=xlab, ylab=ylab,  ...)
    }
    if (!(gc && marker)) {         # If only single plots generated, add SSU and tRNA overlay. If double plot generated, ignore.
        if (ssu && !is.na(x$ssu)) {
            ssu.stats <- merge.scaff.marker(x$diffcov, x$ssu, taxon, consensus=FALSE)
            points(ssu.stats$Avg_fold_1, ssu.stats$Avg_fold_2, pch=10, cex=2, col="black")
            if(textlabel==TRUE) {
                text(ssu.stats$Avg_fold_1,ssu.stats$Avg_fold_2,as.character(ssu.stats$taxon),pos=3,offset=0.2,font=2)
            }
        }
        if (trna && !is.na(x$trna)) {
            trna.stats <- merge(x$diffcov,x$trna,by.x="ID",by.y="scaffold")
            points(trna.stats$Avg_fold_1,trna.stats$Avg_fold_2,pch=4,cex=1,col="black")
        }
    }
}
