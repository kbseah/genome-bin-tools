diffcovstatsbin <-
function(shortlist,x,taxon,points,save,file) UseMethod ("diffcovstatsbin")
