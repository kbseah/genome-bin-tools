print.genomestatsbin <-
function(x) {
    cat("Object of class genomestatsbin\n")
    cat ("\nSummary:\n")
    print(x$summary)
}
