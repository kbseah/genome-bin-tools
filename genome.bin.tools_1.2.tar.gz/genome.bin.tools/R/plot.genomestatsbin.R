plot.genomestatsbin <-
function(x, ... ) {              # inherit the same plot method as genomestats class for simplicity
    plot.genomestats (x, ...)
}
