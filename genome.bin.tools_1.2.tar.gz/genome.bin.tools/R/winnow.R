winnow <- 
function(x,gc=c(0,1),cov=c(0,Inf),cov2=c(0,Inf),len=c(0,Inf),save=FALSE,file="bin_scaffolds.list") {
    # "Winnow" a genomestats(bin) or diffcovstats(bin) object by GC%
    # Only return those contigs which are in that GC range
    if (class(x) == "genomestatsbin" | class(x) =="genomestats") {
        scafflist <- as.character(x$scaff$ID[which(x$scaff$Ref_GC >gc[1] & x$scaff$Ref_GC < gc[2] & x$scaff$Avg_fold>cov[1] & x$scaff$Avg_fold<cov[2] & x$scaff$Length>len[1] & x$scaff$Length<len[2])])
        winnowedbin <- genomestatsbin (shortlist=scafflist, x=x, points=NA, save=save, file=file)
        return(winnowedbin)
    }
    if (class(x) == "diffcovstatsbin" | class(x) == "diffcovstats") {
        scafflist <- as.character(x$diffcov$ID[which(x$diffcov$Ref_GC > gc[1] & x$diffcov$Ref_GC < gc[2] & x$diffcov$Avg_fold_1>cov[1] & x$diffcov$Avg_fold_1<cov[2] & x$diffcov$Avg_fold_2>cov2[1] & x$diffcov$Avg_fold_2<cov2[2] & x$diffcov$Length>len[1] & x$diffcov$Length<len[2])])
        winnowedbin <- diffcovstatsbin (shortlist=scafflist, x=x, points=NA, save=save, file=file)
        return(winnowedbin)
    }
    else {cat ("Object must be of class genomestats, genomestatsbin, diffcovstats, or diffcovstatsbin!\n")}
}