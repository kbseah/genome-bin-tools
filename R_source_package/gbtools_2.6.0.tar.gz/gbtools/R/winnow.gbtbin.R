#' @export
#'
winnow.gbtbin <- winnow.gbt  # Inherit behavior of gbt method
