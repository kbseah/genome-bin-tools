#' @export

winnowMark.gbtbin <- winnowMark.gbt
