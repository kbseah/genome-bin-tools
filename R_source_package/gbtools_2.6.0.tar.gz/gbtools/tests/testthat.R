library(testthat)
library(gbtools)

test_check("gbtools")
